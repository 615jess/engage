<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );

/** MySQL database username */
define( 'DB_USER', '' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', '' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ppxgqsvcxpshhzmnty1rwejnxsnztapo2xily82nrlirbwqvfxnr65hdanhwpuq1' );
define( 'SECURE_AUTH_KEY',  'nkbrfd2vxdz5zusjubpdpr9naoh8lq9bc9tkvejd4ydeijhy3vnzlqdbkm2f0eld' );
define( 'LOGGED_IN_KEY',    '3ulzuunzeeni5rxwsqw4ogurlr749uknzvgykoglbpbsukqsctdxayxu4c6zbhoc' );
define( 'NONCE_KEY',        'frazv7elki5si3qg6edknhims8ire0sqaho7brbrliuplngvedfjrwqaqm5vndiv' );
define( 'AUTH_SALT',        '6pqcdxhay8a0sxycxqqqkshtwfq84duv5clrzu7idbvpmpl9fumptmucy9eu8pil' );
define( 'SECURE_AUTH_SALT', 'yqthigdmiyudfmwpfvbkz9fntzzzyo5di1alpvtqwzabef7nng7uenbccctlawly' );
define( 'LOGGED_IN_SALT',   'ejzwfgtu0kz0o4a9wxtozhobay4wlz1ekpfqpkmadchzodmtiodmmqpad92cvnuy' );
define( 'NONCE_SALT',       'x0xsnubh2bp3fyx9kpnssdqiixgyhtofegqzntx8pje00vl9lflujqr2ukgraxt7' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpnv_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
